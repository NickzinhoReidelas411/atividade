import { StyleSheet, Text, View } from "react-native";

type GradeHorariaProps = {
  cor?: string;
};

const dias = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta"];

export function GradeHoraria({ cor = "#00d4ff" }: GradeHorariaProps) {
  return (
    <View style={[styles.grade, { borderColor: cor }]}>
      <Text style={[styles.titulo, { color: cor }]}>Grade Horária</Text>
      <Text style={styles.observacao}>
        Horário informado no curso. As disciplinas de cada dia podem seguir a
        grade específica da turma.
      </Text>

      <View style={styles.cabecalho}>
        <Text style={styles.celula}>Dia</Text>
        <Text style={styles.celula}>Entrada</Text>
        <Text style={styles.celula}>Intervalo</Text>
        <Text style={styles.celula}>Saída</Text>
      </View>

      {dias.map((dia) => (
        <View key={dia} style={styles.linha}>
          <Text style={[styles.celula, styles.dia]}>{dia}</Text>
          <Text style={styles.celula}>13:30</Text>
          <Text style={styles.celula}>16:00 - 16:20</Text>
          <Text style={styles.celula}>18:50</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  grade: {
    width: "100%",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
  },
  titulo: {
    fontSize: 18,
    fontWeight: "bold",
    paddingHorizontal: 14,
    paddingTop: 14,
  },
  observacao: {
    color: "#ccc",
    fontSize: 12,
    lineHeight: 18,
    paddingHorizontal: 14,
    paddingTop: 6,
    paddingBottom: 12,
  },
  cabecalho: {
    flexDirection: "row",
    backgroundColor: "rgba(255, 255, 255, 0.08)",
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.1)",
  },
  linha: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.1)",
  },
  celula: {
    color: "#fff",
    fontSize: 11,
    textAlign: "center",
    paddingVertical: 10,
    paddingHorizontal: 2,
    flex: 1,
    borderLeftWidth: 1,
    borderLeftColor: "rgba(255, 255, 255, 0.1)",
  },
  dia: {
    fontWeight: "600",
  },
});
