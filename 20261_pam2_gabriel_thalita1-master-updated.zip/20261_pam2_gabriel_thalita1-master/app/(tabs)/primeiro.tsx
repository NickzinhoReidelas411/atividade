// Importamos o básico do react-native (essencial para não dar erro de 'não encontrado')
import { ScrollView, StatusBar, StyleSheet, Text, View } from "react-native";

import { GradeHoraria } from "@/components/grade-horaria";

export default function HomeScreen() {
  return (
    // SafeAreaView ou View para a cor de fundo não vazar
    <View style={styles.background}>
      <StatusBar barStyle="light-content" />

      <ScrollView
        // A "janela" por onde vemos o conteúdo
        style={styles.background}
        // O "recheio" que realmente rola
        contentContainerStyle={styles.container}
      >
        <Text style={styles.titulo}>1MD2</Text>

        <View style={styles.card}>
          <Text style={styles.subtitulo}>Primeiro Ano</Text>
          <Text style={styles.descricao}>
            Auxiliar Técnico em Desenvolvimento de Sistemas.
          </Text>
        </View>

        <Text style={styles.textoFundo}>Informações Gerais do Curso</Text>

        {/* --- TABELA FIXA: FICHA TÉCNICA --- */}
        <View style={styles.fichaTecnica}>
          <View style={styles.fichaLinha}>
            <Text style={styles.fichaLabel}>Carga Horária Total:</Text>
            <Text style={styles.fichaValor}>1.200 horas</Text>
          </View>
          <View style={styles.fichaLinha}>
            <Text style={styles.fichaLabel}>Parte Técnica:</Text>
            <Text style={styles.fichaValor}>800 horas</Text>
          </View>
          <View style={styles.fichaLinha}>
            <Text style={styles.fichaLabel}>Base Comum:</Text>
            <Text style={styles.fichaValor}>400 horas</Text>
          </View>
          <View style={styles.fichaLinha}>
            <Text style={styles.fichaLabel}>Período:</Text>
            <Text style={styles.fichaValor}>Vespertino</Text>
          </View>
          <View style={styles.fichaLinhaSemBorda}>
            <Text style={styles.fichaLabel}>Horário:</Text>
            <Text style={styles.fichaValor}>Seg a Sex das 13:30 às 18:50</Text>
          </View>
        </View>

        <GradeHoraria cor="#ff00b3" />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: "#530142", // Azul Marinho Profundo
  },
  container: {
    // IMPORTANTE: flexGrow permite que o justifyContent funcione no ScrollView
    flexGrow: 1,
    padding: 30,
    alignItems: "center",
    justifyContent: "center", // Alinhamento Vertical Central
    gap: 20,
  },
  titulo: {
    color: "#ff00b3", // Azul ciano brilhante (estilo Tech)
    fontSize: 32,
    fontWeight: "bold",
    letterSpacing: 2,
    marginBottom: 10,
  },
  card: {
    backgroundColor: "rgba(255, 255, 255, 0.1)", // Branco transparente
    padding: 20,
    borderRadius: 15,
    width: "100%",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ff00b3",
  },
  subtitulo: {
    color: "#FFF",
    fontSize: 20,
    fontWeight: "600",
  },
  descricao: {
    color: "#ccc",
    textAlign: "center",
    marginTop: 10,
    lineHeight: 22,
  },
  textoFundo: {
    color: "#555",
    fontSize: 12,
    marginTop: 20,
    textTransform: "uppercase",
  },
  fichaTecnica: {
    width: "100%",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#ff00b3",
  },

  fichaLinha: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.1)",
  },
  fichaLinhaSemBorda: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
  },

  fichaLabel: {
    color: "#ff00b3",
    fontWeight: "600",
    fontSize: 14,
  },
  fichaValor: {
    color: "#fff",
    fontSize: 14,
    textAlign: "right",
    flex: 1,
  },
});
