import React, { useState } from "react";
// Importamos o básico do react-native (essencial para não dar erro de 'não encontrado')
import {
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { disciplinasPorAno, type Ano } from "@/constants/curso";

const anos = [
  {
    id: "primeiro" as Ano,
    titulo: "Primeiro Ano",
    sigla: "1MD2",
    descricao: "Auxiliar Técnico em Desenvolvimento de Sistemas.",
    cor: "#ff00b3",
  },
  {
    id: "segundo" as Ano,
    titulo: "Segundo Ano",
    sigla: "2MD2",
    descricao: "Programador de Computadores.",
    cor: "#ff0000",
  },
  {
    id: "terceiro" as Ano,
    titulo: "Terceiro Ano",
    sigla: "3MD2",
    descricao: "Técnico em Desenvolvimento de Sistemas.",
    cor: "#430cda",
  },
];

export default function HomeScreen() {
  const [anoAberto, setAnoAberto] = useState<Ano | null>(null);

  const alternarAno = (ano: Ano) => {
    setAnoAberto((atual) => (atual === ano ? null : ano));
  };

  return (
    // SafeAreaView ou View para a cor de fundo não vazar
    <View style={styles.background}>
      <StatusBar barStyle="light-content" />

      <ScrollView
        // A "janela" por onde vemos o conteúdo
        style={styles.background}
        // O "recheio" que realmente rola
        contentContainerStyle={styles.container}>
        <Text style={styles.titulo}>ETEC Adolpho Berezin</Text>

        <View style={styles.card}>
          <Text style={styles.subtitulo}>Desenvolvimento de Sistemas</Text>
          <Text style={styles.descricao}>
            Curso completo para desenvolvedores desktop, web e mobile
          </Text>
        </View>

        <Text style={styles.textoFundo}>Informações Gerais do Curso</Text>

        {/* --- TABELA FIXA: FICHA TÉCNICA --- */}
        <View style={styles.fichaTecnica}>
          <View style={styles.fichaLinha}>
            <Text style={styles.fichaLabel}>Carga Horária Total:</Text>
            <Text style={styles.fichaValor}>1.200 horas</Text>
          </View>
          <View style={styles.fichaLinha}>
            <Text style={styles.fichaLabel}>Parte Técnica:</Text>
            <Text style={styles.fichaValor}>800 horas</Text>
          </View>
          <View style={styles.fichaLinha}>
            <Text style={styles.fichaLabel}>Base Comum:</Text>
            <Text style={styles.fichaValor}>400 horas</Text>
          </View>
          <View style={styles.fichaLinha}>
            <Text style={styles.fichaLabel}>Período:</Text>
            <Text style={styles.fichaValor}>Vespertino</Text>
          </View>
          <View style={styles.fichaLinhaSemBorda}>
            <Text style={styles.fichaLabel}>Horário:</Text>
            <Text style={styles.fichaValor}>Seg a Sex das 13:30 às 18:50</Text>
          </View>
        </View>

        <Text style={styles.secaoTitulo}>Disciplinas por Ano</Text>

        {anos.map((ano) => {
          const aberto = anoAberto === ano.id;
          const disciplinas = disciplinasPorAno[ano.id];

          return (
            <View key={ano.id} style={[styles.anoCard, { borderColor: ano.cor }]}>
              <Pressable
                onPress={() => alternarAno(ano.id)}
                style={styles.anoCabecalho}>
                <View style={styles.anoTexto}>
                  <Text style={[styles.anoSigla, { color: ano.cor }]}>
                    {ano.sigla}
                  </Text>
                  <Text style={styles.anoTitulo}>{ano.titulo}</Text>
                  <Text style={styles.anoDescricao}>{ano.descricao}</Text>
                </View>
                <Text style={[styles.icone, { color: ano.cor }]}>
                  {aberto ? "−" : "+"}
                </Text>
              </Pressable>

              {aberto && (
                <View style={styles.disciplinas}>
                  <Text style={[styles.grupoTitulo, { color: ano.cor }]}>
                    Base Comum
                  </Text>
                  {disciplinas.baseComum.map((disciplina) => (
                    <View key={disciplina} style={styles.disciplinaLinha}>
                      <Text style={styles.marcador}>•</Text>
                      <Text style={styles.disciplina}>{disciplina}</Text>
                    </View>
                  ))}

                  <Text style={[styles.grupoTitulo, { color: ano.cor }]}>
                    Formação Técnica
                  </Text>
                  {disciplinas.tecnico.map((disciplina) => (
                    <View key={disciplina} style={styles.disciplinaLinha}>
                      <Text style={styles.marcador}>•</Text>
                      <Text style={styles.disciplina}>{disciplina}</Text>
                    </View>
                  ))}
                </View>
              )}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: "#001a33", // Azul Marinho Profundo
  },
  container: {
    // IMPORTANTE: flexGrow permite que o justifyContent funcione no ScrollView
    flexGrow: 1,
    padding: 30,
    alignItems: "center",
    justifyContent: "center", // Alinhamento Vertical Central
    gap: 20,
  },
  titulo: {
    color: "#00d4ff", // Azul ciano brilhante (estilo Tech)
    fontSize: 32,
    fontWeight: "bold",
    letterSpacing: 2,
    marginBottom: 10,
  },
  card: {
    backgroundColor: "rgba(255, 255, 255, 0.1)", // Branco transparente
    padding: 20,
    borderRadius: 15,
    width: "100%",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#00d4ff",
  },
  subtitulo: {
    color: "#FFF",
    fontSize: 20,
    fontWeight: "600",
  },
  descricao: {
    color: "#ccc",
    textAlign: "center",
    marginTop: 10,
    lineHeight: 22,
  },
  textoFundo: {
    color: "#555",
    fontSize: 12,
    marginTop: 20,
    textTransform: "uppercase",
  },
  fichaTecnica: {
    width: "100%",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#00d4ff",
  },

  fichaLinha: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.1)",
  },
  fichaLinhaSemBorda: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
  },

  fichaLabel: {
    color: "#00d4ff",
    fontWeight: "600",
    fontSize: 14,
  },
  fichaValor: {
    color: "#fff",
    fontSize: 14,
    textAlign: "right",
    flex: 1,
  },
  secaoTitulo: {
    color: "#fff",
    width: "100%",
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 5,
  },
  anoCard: {
    width: "100%",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 15,
    borderWidth: 1,
    overflow: "hidden",
  },
  anoCabecalho: {
    flexDirection: "row",
    alignItems: "center",
    padding: 18,
  },
  anoTexto: {
    flex: 1,
  },
  anoSigla: {
    fontSize: 12,
    fontWeight: "bold",
    letterSpacing: 1,
  },
  anoTitulo: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "600",
    marginTop: 2,
  },
  anoDescricao: {
    color: "#ccc",
    fontSize: 13,
    marginTop: 6,
    lineHeight: 19,
  },
  icone: {
    fontSize: 28,
    fontWeight: "300",
    paddingLeft: 12,
  },
  disciplinas: {
    paddingHorizontal: 18,
    paddingBottom: 18,
  },
  grupoTitulo: {
    fontSize: 13,
    fontWeight: "bold",
    marginTop: 8,
    marginBottom: 6,
    textTransform: "uppercase",
  },
  disciplinaLinha: {
    flexDirection: "row",
    alignItems: "flex-start",
    paddingVertical: 3,
  },
  marcador: {
    color: "#fff",
    marginRight: 8,
  },
  disciplina: {
    color: "#eee",
    flex: 1,
    fontSize: 13,
    lineHeight: 18,
  },
});
